$(document).ready(function () {
    $('#user').validate({
        rules: {
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 6
            },
            cpassword: {
                required: true,
                equalTo: "#password"
            }
        },
        messages: {
            email: "Please enter a valid email address",
            password: {
                required: "Please enter a password",
                minlength: "Password must be at least 6 characters long"
            },
            cpassword: {
                required: "Please repeat password",
                equalTo: "Passwords do not match"
            }
        },
        errorElement: 'span',
        errorPlacement: function (error, element) {
            error.addClass('invalid-feedback');
            element.closest('.form-group').append(error);
        },
        highlight: function (element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        }
    });
});