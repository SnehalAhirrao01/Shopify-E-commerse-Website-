<?php

class Admin extends CI_Controller {
	public function index()
	{
	}

	// public function userList()
	// {
	// 	$this->load->view('Admin/userList');
	// }
	
}
