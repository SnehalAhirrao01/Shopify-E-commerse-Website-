<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index() {
        // Check if the form is submitted using POST
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            // Set validation rules
            $this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');

            if ($this->form_validation->run() === FALSE) {
                // Validation failed, reload the login form with errors
                $this->load->view('Admin/login');
            } else {
                $this->load->model('Usermodel');

                // Get user input
                $email = $this->input->post('email');
                $password = $this->input->post('password');

                $user = $this->Usermodel->authenticate($email);

                if ($user && password_verify($password, $user->password)) {
                    // Use the correct variables in the user_data array
                    $user_data = array(
                        'user_id' => $user->id,
                        'email' => $user->email,
                        'logged_in' => TRUE
                    );

                    // Set user data in session and redirect to the dashboard
                    $this->session->set_userdata($user_data);
                    redirect('Dashboard/index');
                } else {
                    $this->session->set_flashdata('login_error', 'Invalid email or password');
                    $this->load->view('Admin/login');
                }
            }
        } else {
            // If it's not a POST request, just load the login view
            $this->load->view('Admin/login');
        }
    }

    public function register()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Set validation rules
            $this->form_validation->set_rules('name', 'Full Name', 'trim|required');
            $this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
            $this->form_validation->set_rules('cpassword', 'Repeat Password', 'trim|required|matches[password]');
            $this->form_validation->set_rules('address', 'Address', 'trim|required');
            $this->form_validation->set_rules('country', 'Country', 'trim|required');

            // Run validation
            if ($this->form_validation->run() === FALSE) {
                $this->load->view('Admin/register');
            } else {
                $this->load->model('Usermodel');

                // Get user input
                $name = $this->input->post('name');
                $email = $this->input->post('email');
                $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
                $address = $this->input->post('address');
                $country = $this->input->post('country');

                // Check if the email is unique
                if ($this->Usermodel->is_email_unique($email)) {
                    $data = array(
                        'name' => $name,
                        'email' => $email,
                        'password' => $password,
                        'address' => $address,
                        'country' => $country,
                    );

                    // Insert data into the Users table
                    if ($this->Usermodel->insert_user($data)) {
                        redirect('auth/index');
                    } else {
                        $this->session->set_flashdata('register_err', 'Registration failed. Please try again');
                    }
                } else {
                    $this->session->set_flashdata('reister_err', 'Email address already exists.');
                }
            }
        } else {
            // If it's not a POST request, just load the registration view
            $this->load->view('Admin/register');
        }
    }

    public function forgotPassword()
    {
        // Check if the form is submitted
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            // Validate form inputs
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');

            if ($this->form_validation->run() === TRUE) {
                $email = $this->input->post('email');
                $password = $this->input->post('password');

                // Check if the email exists in the users table
                $userModel = new UserModel(); 
                $user = $userModel->where('email', $email)->get()->getRow();

                if ($user) {
                    // Update the user's password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $userModel->set('password', $hashedPassword)->where('user_id', $user->user_id)->update();

                    // Display success message or redirect to login page
                    $this->session->set_flashdata('reset_success', 'Password reset successfully.');
                    redirect('auth/login');
                } else {
                    // Email does not exist in the users table
                    $data['email_not_found'] = 'Email not found. Please enter a valid email address.';
                }
            }
        }

        // Load the view with appropriate data
        $this->load->view('Admin/forgotPassword');
    }
}
?>
