<?php

class Users extends CI_Controller {
	public function index()
	{
        $this->load->view('Users/view');
    }

    public function add()
	{
        $this->load->view('Users/add');
    }
}
