<?php
class Usermodel extends CI_Model {

    function __construct() {
        parent::__construct();
    }
  
    public function insert_user($data)
    {
        return $this->db->insert('Users', $data);
    }
  
    public function is_email_unique($email)
    {
        $this->db->where('email', $email);
        $query = $this->db->get('Users');

        return $query->num_rows() === 0;
    }

    public function authenticate($email)
    {
        // Get user by email from the Users table
        return $this->db->get_where('Users', ['email' => $email])->row();
    }
    
}
?> 